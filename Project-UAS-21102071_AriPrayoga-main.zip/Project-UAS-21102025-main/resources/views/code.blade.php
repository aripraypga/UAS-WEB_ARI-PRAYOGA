@extends('layouts.default')

@section('content')
<section>
    <div class="conttainer mt-5">
        <div class="row">
            <div class="col-lg-8">
        <h3>CODINGAN PROJECT</h3>
</div>
          <div class ="col-lg-55">
          <table class="table table-bordered border-primary">
            <tr>
            <center><img src="img/kodingan1.jpg" width="1080px" ></center>
            <center><img src="img/kodingan2.jpg" width="1080px" ></center>
            <center><img src="img/kodingan3.jpg" width="1080px" ></center>

            </tr>
                    
                    
</section>
@endsection
